# Week 04 – Student Registration System

ITST 302 – Client-Server Technologies | Mini Project 03

A Laravel-based Student Registration System demonstrating Blade forms, server-side validation, flash messages, secure profile-picture upload, MySQL database integration, and a student profile page.

## Features

- Responsive registration form
- Required-field validation
- Unique Student ID and email
- Email, numeric, date, gender, program, and year-level validation
- JPG/JPEG/PNG profile picture upload up to 2 MB
- Laravel Storage integration
- Success flash message
- Student profile page
- Registered student directory
- Laravel MVC structure
- Git history with 10+ meaningful commits

## Requirements

- PHP 8.2+
- Composer
- MySQL
- Laravel 13
- Git

## Setup

```bash
git clone <your-repository-url>
cd week04-student-registration
composer install
copy .env.example .env
php artisan key:generate
```

Create a MySQL database named `student_registration`, then update `.env`:

```env
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=student_registration
DB_USERNAME=root
DB_PASSWORD=
FILESYSTEM_DISK=public
```

Run:

```bash
php artisan migrate
php artisan storage:link
php artisan serve
```

Open `http://127.0.0.1:8000`.

## Laravel Request Flow

```text
Browser
   ↓
Route → StudentController
   ↓
Validation
   ↓
Student Model
   ↓
MySQL students table
   ↓
Redirect + Flash Message
   ↓
Student Profile
```

The flow demonstrates the request lifecycle required by the activity: the browser submits the form, the route dispatches the request to the controller, validation checks the input, the model persists the record, and Laravel returns the profile response with a success notification.

## Main Routes

| Method | URL | Purpose |
|---|---|---|
| GET | `/students/create` | Registration form |
| POST | `/students` | Save registration |
| GET | `/students/{student}` | Student profile |
| GET | `/students` | Student directory |

## Validation

The system validates Student ID uniqueness, required names, unique/valid email, numeric mobile number, required academic information, and profile-picture type/size. Validation occurs on the server before a student record is saved.

## File Upload

Images are stored using Laravel's `public` disk under `storage/app/public/student-profiles`. Only the resulting file path is stored in the database.

## Git Commit Strategy

The repository intentionally uses small, meaningful commits that mirror the development process:

1. `chore: initialize Laravel student registration project`
2. `feat: add student database migration`
3. `feat: create Student model`
4. `feat: add student controller and routes`
5. `feat: build responsive registration form`
6. `feat: implement server-side validation`
7. `feat: add profile picture upload`
8. `feat: add registration success flash message`
9. `feat: create student profile page`
10. `feat: add registered students directory`
11. `docs: add project README`

## Required Documentation To Add Before Submission

The activity requires screenshots and diagrams in addition to the working system. Add these to the repository before final submission:

- `documentation/registration-flowchart.png`
- `documentation/database-erd.png`
- `documentation/laravel-request-lifecycle.png`
- `screenshots/registration-form.png`
- `screenshots/validation-errors.png`
- `screenshots/flash-success.png`
- `screenshots/student-profile.png`
- `screenshots/database-records.png`
- `screenshots/project-structure.png`
- `screenshots/github-repository.png`
- `screenshots/terminal-output.png`
- `screenshots/browser-output.png`

The course activity specifically requires a public GitHub repository, at least 10 meaningful commits, complete README documentation, the three diagrams, screenshots, and a LinkedIn portfolio post. See the original activity brief for the complete submission requirements.
