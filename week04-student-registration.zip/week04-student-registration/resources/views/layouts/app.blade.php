<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Student Registration')</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
</head>
<body>
<header class="topbar">
    <a href="{{ route('students.create') }}" class="brand">
        <span class="brand-mark">SR</span>
        <span>Student Registration</span>
    </a>
    <nav>
        <a href="{{ route('students.create') }}">Register</a>
        <a href="{{ route('students.index') }}">Students</a>
    </nav>
</header>

<main class="page-shell">
    @if(session('success'))
        <div class="alert success" role="alert">
            <span class="alert-icon">✓</span>
            <div>
                <strong>Registration complete</strong>
                <p>{{ session('success') }}</p>
            </div>
        </div>
    @endif

    @yield('content')
</main>
<footer class="site-footer">ITST 302 · Student Registration System <span>Laravel MVC</span></footer>
</body>
</html>