@extends('layouts.app')

@section('title', 'Register Student')

@section('content')
<div class="hero">
    <div>
        <span class="eyebrow">ITST 302 · WEEK 4</span>
        <h1>Register a student</h1>
        <p>Create a secure student record with validated information and a profile picture.</p>
    </div>
    <div class="hero-badge">
        <span class="status-dot"></span>
        Secure registration
    </div>
</div>

@if($errors->any())
<div class="alert error">
    <span class="alert-icon">!</span>
    <div>
        <strong>Please review your submission</strong>
        <ul>
            @foreach($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
</div>
@endif

<form action="{{ route('students.store') }}" method="POST" enctype="multipart/form-data" class="card form-card">
    @csrf

    <section class="form-section">
        <div class="section-heading">
            <div class="section-number">01</div>
            <div><h2>Student identity</h2><p>Basic information used to identify the student.</p></div>
        </div>

        <div class="grid grid-3">
            <div class="field">
                <label for="student_id">Student ID <span>*</span></label>
                <input id="student_id" name="student_id" value="{{ old('student_id') }}" placeholder="e.g. 2026-0001" required>
                @error('student_id')<small>{{ $message }}</small>@enderror
            </div>
            <div class="field">
                <label for="first_name">First Name <span>*</span></label>
                <input id="first_name" name="first_name" value="{{ old('first_name') }}" placeholder="Juan" required>
                @error('first_name')<small>{{ $message }}</small>@enderror
            </div>
            <div class="field">
                <label for="middle_name">Middle Name</label>
                <input id="middle_name" name="middle_name" value="{{ old('middle_name') }}" placeholder="Santos">
                @error('middle_name')<small>{{ $message }}</small>@enderror
            </div>
            <div class="field">
                <label for="last_name">Last Name <span>*</span></label>
                <input id="last_name" name="last_name" value="{{ old('last_name') }}" placeholder="Dela Cruz" required>
                @error('last_name')<small>{{ $message }}</small>@enderror
            </div>
            <div class="field">
                <label for="email">Email Address <span>*</span></label>
                <input id="email" type="email" name="email" value="{{ old('email') }}" placeholder="juan@example.com" required>
                @error('email')<small>{{ $message }}</small>@enderror
            </div>
            <div class="field">
                <label for="mobile_number">Mobile Number <span>*</span></label>
                <input id="mobile_number" name="mobile_number" value="{{ old('mobile_number') }}" placeholder="09171234567" inputmode="numeric" required>
                @error('mobile_number')<small>{{ $message }}</small>@enderror
            </div>
        </div>
    </section>

    <section class="form-section">
        <div class="section-heading">
            <div class="section-number">02</div>
            <div><h2>Academic information</h2><p>Program and enrollment details.</p></div>
        </div>

        <div class="grid grid-3">
            <div class="field">
                <label for="date_of_birth">Date of Birth <span>*</span></label>
                <input id="date_of_birth" type="date" name="date_of_birth" value="{{ old('date_of_birth') }}" required>
                @error('date_of_birth')<small>{{ $message }}</small>@enderror
            </div>
            <div class="field">
                <label for="gender">Gender <span>*</span></label>
                <select id="gender" name="gender" required>
                    <option value="">Select gender</option>
                    @foreach(['Male','Female','Other'] as $option)
                        <option value="{{ $option }}" @selected(old('gender') === $option)>{{ $option }}</option>
                    @endforeach
                </select>
                @error('gender')<small>{{ $message }}</small>@enderror
            </div>
            <div class="field">
                <label for="year_level">Year Level <span>*</span></label>
                <select id="year_level" name="year_level" required>
                    <option value="">Select year</option>
                    @foreach(['1st Year','2nd Year','3rd Year','4th Year','5th Year'] as $option)
                        <option value="{{ $option }}" @selected(old('year_level') === $option)>{{ $option }}</option>
                    @endforeach
                </select>
                @error('year_level')<small>{{ $message }}</small>@enderror
            </div>
            <div class="field field-wide">
                <label for="program">Program <span>*</span></label>
                <input id="program" name="program" value="{{ old('program') }}" placeholder="BS Information Technology" required>
                @error('program')<small>{{ $message }}</small>@enderror
            </div>
            <div class="field field-wide">
                <label for="address">Address <span>*</span></label>
                <textarea id="address" name="address" rows="3" placeholder="House / Street, Barangay, Municipality, Province" required>{{ old('address') }}</textarea>
                @error('address')<small>{{ $message }}</small>@enderror
            </div>
        </div>
    </section>

    <section class="form-section">
        <div class="section-heading">
            <div class="section-number">03</div>
            <div><h2>Profile picture</h2><p>Upload a JPG or PNG image up to 2 MB.</p></div>
        </div>

        <label class="upload-box" for="profile_picture">
            <span class="upload-icon">↑</span>
            <strong>Choose profile picture</strong>
            <span id="file-name">JPG, JPEG or PNG · Maximum 2 MB</span>
            <input id="profile_picture" type="file" name="profile_picture" accept=".jpg,.jpeg,.png,image/jpeg,image/png" required onchange="document.getElementById('file-name').textContent = this.files[0]?.name || 'JPG, JPEG or PNG · Maximum 2 MB'">
        </label>
        @error('profile_picture')<small class="upload-error">{{ $message }}</small>@enderror
    </section>

    <div class="form-footer">
        <span><b>*</b> Required fields</span>
        <button class="button" type="submit">Register student <span>→</span></button>
    </div>
</form>
@endsection